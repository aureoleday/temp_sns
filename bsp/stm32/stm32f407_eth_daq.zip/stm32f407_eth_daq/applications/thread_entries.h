#ifndef	__THREADS_ENTRIES
#define	__THREADS_ENTRIES
void modbus_slave_thread_entry(void* parameter);

#endif	//__THREADS_ENTRIES
